package audio;

import java.util.ArrayList;

public class PlayList {

	public static ArrayList<Music> musics = new ArrayList<Music>();
	public static String[] titles = {};

	public static void run(String title, Music.SoundType TYPE) {
		//if (!exist(title))return;

		musics.add(new Music(title, TYPE));
	}

	public static boolean exist(String title) {
		for (String s : titles)
			if (s.equals(title))
				return true;
		return false;
	}

	public static void stop(String title) {
		for (Music m : musics)
			if (m.getTitle().equals(title))
				m.stop();
	}

	public static void stop() {
		for (Music m : musics)
			m.stop();
	}

}
