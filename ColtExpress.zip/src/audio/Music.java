package audio;

import javax.sound.sampled.*;
import java.io.IOException;
import java.io.InputStream;

public class Music {

	private String title;
	private SoundType TYPE;
	private FloatControl pan, volume;
	private boolean isRunning = false;

	private static float panMainValue = 0.0f, volumeMainValue = -10.0f;

	public Music(String title, SoundType TYPE) {
		this.title = title;
		this.TYPE = TYPE;
		play();
	}

	public String getTitle() {
		return title;
	}

	/*public void setTitle(String title) {
		this.title = title;
	}*/

	public SoundType getTYPE() {
		return TYPE;
	}

	public void setTYPE(SoundType TYPE) {
		this.TYPE = TYPE;
	}

	public enum SoundType {
		MUSIC, EFFECT
	}

	public void play() {
		Thread t = new Thread(new Runnable() {

			@SuppressWarnings("unlikely-arg-type")
			@Override
			public void run() {
				SourceDataLine line;
				AudioInputStream audioInputStream;
				AudioFormat audioFormat;

				InputStream inputStream = Music.class.getResourceAsStream("/libs/audio/" + title);

				try {
					audioInputStream = AudioSystem.getAudioInputStream(inputStream);
				} catch (UnsupportedAudioFileException | IOException e) {
					e.printStackTrace();
					return;
				}

				audioFormat = audioInputStream.getFormat();
				DataLine.Info info = new DataLine.Info(SourceDataLine.class, audioFormat);
				try {
					line = (SourceDataLine) AudioSystem.getLine(info);
					line.open(audioFormat);
				} catch (LineUnavailableException e) {
					e.printStackTrace();
					return;
				}

				line.start();
				isRunning = true;

				if (line.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
					volume = (FloatControl)line.getControl(FloatControl.Type.MASTER_GAIN);

					if (line.isControlSupported(FloatControl.Type.PAN)) {
						pan = (FloatControl)line.getControl(FloatControl.Type.PAN);

						byte[] bytes = new byte[5000];
						int bytesRead =  0;

						pan.setValue(panMainValue);
						volume.setValue(volumeMainValue);

						try {
							while ((bytesRead = audioInputStream.read(bytes, 0, bytes.length)) != -1 && isRunning) {
								if (pan.getValue() != panMainValue)pan.setValue(panMainValue);
								if (volume.getValue() != volumeMainValue)volume.setValue(volumeMainValue);
								line.write(bytes, 0, bytesRead);
							}
						} catch (IOException e) {
							e.printStackTrace();
							return;
						}
						line.close();
						isRunning = false;
					}
				}
				PlayList.musics.remove(this);
			}
		});
		t.start();
	}

	public void stop() {
		isRunning = false;
	}

}
